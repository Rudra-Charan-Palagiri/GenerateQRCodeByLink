import React, { useState } from 'react';
import Header from './Header';
import Footer from './Footer';
import './Volunteers.css';

const Volunteers = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    skills: [],
    availability: [],
    emergencyContactName: '',
    emergencyContactPhone: '',
    comments: ''
  });

  const [submitted, setSubmitted] = useState(false);

  const skillOptions = [
    'Medical', 'Search & Rescue', 'Firefighting', 'Communication', 
    'Logistics', 'Construction', 'Counseling', 'Cooking', 
    'Transportation', 'Child Care', 'First Aid', 'Technical'
  ];

  const availabilityOptions = [
    'Weekday Mornings', 'Weekday Afternoons', 'Weekday Evenings', 
    'Weekend Mornings', 'Weekend Afternoons', 'Weekend Evenings',
    'On-Call 24/7', 'Remote Only'
  ];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCheckboxChange = (e) => {
    const { name, value, checked } = e.target;
    if (checked) {
      setFormData(prev => ({
        ...prev,
        [name]: [...prev[name], value]
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: prev[name].filter(item => item !== value)
      }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.firstName || !formData.lastName || !formData.email || !formData.phone) {
      alert("Please fill in all required fields.");
      return;
    }
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      alert("Please enter a valid email address.");
      return;
    }
    
    // In a real app, you would send this data to your backend
    console.log('Volunteer registered:', formData);
    
    // Success message
    setSubmitted(true);
    
    // Reset form after a delay
    setTimeout(() => {
      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        address: '',
        city: '',
        state: '',
        zipCode: '',
        skills: [],
        availability: [],
        emergencyContactName: '',
        emergencyContactPhone: '',
        comments: ''
      });
      setSubmitted(false);
    }, 5000);
  };

  return (
    <div className="volunteers-page">
      <Header />
      
      <main className="volunteers-content">
        <h1 className="page-title">Volunteer Management</h1>
        
        <div className="stats-section">
          <div className="stat-box blue">
            <div className="stat-icon">👥</div>
            <h3 className="stat-value">750+</h3>
            <p className="stat-label">Active Volunteers</p>
          </div>
          
          <div className="stat-box green">
            <div className="stat-icon">🛠️</div>
            <h3 className="stat-value">24</h3>
            <p className="stat-label">Teams Deployed</p>
          </div>
          
          <div className="stat-box yellow">
            <div className="stat-icon">🚨</div>
            <h3 className="stat-value">12</h3>
            <p className="stat-label">Active Missions</p>
          </div>
        </div>
        
        <div className="volunteer-grid">
          <div className="info-panel">
            <h2 className="section-title">Why We Need Volunteers</h2>
            <p>
              Volunteers are the backbone of our disaster response efforts. When disasters strike, the need for help often outpaces what professional responders can provide.
            </p>
            <p>
              Your skills, time, and compassion can make a significant difference in the lives of those affected by catastrophes, whether you can offer:
            </p>
            <ul className="skill-list">
              <li>Medical expertise</li>
              <li>Search and rescue experience</li>
              <li>Construction and engineering skills</li>
              <li>Logistics and transportation support</li>
              <li>Communications assistance</li>
              <li>Cooking and food distribution</li>
              <li>Emotional support and counseling</li>
            </ul>
            <p>
              Every contribution matters, and together we can build stronger, more resilient communities.
            </p>
          </div>
          
          <div className="registration-panel">
            {submitted ? (
              <div className="success-message">
                <div className="success-icon">✓</div>
                <h3>Registration Successful</h3>
                <p>Thank you for volunteering! We will contact you soon with more information.</p>
              </div>
            ) : (
              <>
                <h2 className="section-title">Volunteer Registration</h2>
                
                <div className="info-box">
                  <h3 className="info-title">Why Volunteer?</h3>
                  <p>
                    Volunteers are the backbone of disaster response. Your skills and time can make a real difference in helping communities recover from disasters. Join our team to provide essential support when it's needed most.
                  </p>
                </div>
                
                <form onSubmit={handleSubmit} className="registration-form">
                  <h3 className="form-section-title">Personal Information</h3>
                  <div className="form-row">
                    <div className="form-group">
                      <label htmlFor="firstName" className="form-label">
                        First Name*
                      </label>
                      <input
                        type="text"
                        id="firstName"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleChange}
                        className="form-input"
                        required
                      />
                    </div>
                    
                    <div className="form-group">
                      <label htmlFor="lastName" className="form-label">
                        Last Name*
                      </label>
                      <input
                        type="text"
                        id="lastName"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleChange}
                        className="form-input"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="form-row">
                    <div className="form-group">
                      <label htmlFor="email" className="form-label">
                        Email*
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        className="form-input"
                        required
                      />
                    </div>
                    
                    <div className="form-group">
                      <label htmlFor="phone" className="form-label">
                        Phone*
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="form-input"
                        required
                      />
                    </div>
                  </div>
                  
                  <h3 className="form-section-title">Skills & Availability</h3>
                  
                  <div className="form-group">
                    <label className="form-label">
                      Skills (Select all that apply)
                    </label>
                    <div className="checkbox-grid">
                      {skillOptions.map(skill => (
                        <label key={skill} className="checkbox-label">
                          <input
                            type="checkbox"
                            name="skills"
                            value={skill}
                            checked={formData.skills.includes(skill)}
                            onChange={handleCheckboxChange}
                            className="checkbox-input"
                          />
                          <span>{skill}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                  
                  <div className="form-group">
                    <label className="form-label">
                      Availability (Select all that apply)
                    </label>
                    <div className="checkbox-grid">
                      {availabilityOptions.map(time => (
                        <label key={time} className="checkbox-label">
                          <input
                            type="checkbox"
                            name="availability"
                            value={time}
                            checked={formData.availability.includes(time)}
                            onChange={handleCheckboxChange}
                            className="checkbox-input"
                          />
                          <span>{time}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                  
                  <div className="notice-box">
                    <p>
                      By submitting this form, you agree to be contacted regarding volunteer opportunities and understand that you may be called upon in emergency situations if you selected that availability.
                    </p>
                  </div>
                  
                  <div className="form-footer">
                    <button
                      type="submit"
                      className="submit-button"
                    >
                      Register as Volunteer
                    </button>
                  </div>
                </form>
              </>
            )}
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Volunteers;