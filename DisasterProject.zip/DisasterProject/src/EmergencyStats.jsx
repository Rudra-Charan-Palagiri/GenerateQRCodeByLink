import React from 'react';
import './EmergencyStats.css';

const EmergencyStats = () => {
  // Sample data for demonstration
  const stats = [
    { title: 'Active Incidents', value: 24, change: '+3', trend: 'up', color: 'red' },
    { title: 'Volunteers Ready', value: 312, change: '+28', trend: 'up', color: 'green' },
    { title: 'People Affected', value: '2,847', change: '+142', trend: 'up', color: 'yellow' },
    { title: 'Resources Deployed', value: '76%', change: '-3%', trend: 'down', color: 'blue' }
  ];

  return (
    <div className="stats-container">
      {stats.map((stat, index) => (
        <div key={index} className="stat-card">
          <div className="stat-header">
            <div className={`stat-indicator ${stat.color}`}></div>
            <h3 className="stat-title">{stat.title}</h3>
          </div>
          <div className="stat-content">
            <p className="stat-value">{stat.value}</p>
            <p className={`stat-change ${stat.trend}`}>
              {stat.change} {stat.trend === 'up' ? '↑' : '↓'}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default EmergencyStats;