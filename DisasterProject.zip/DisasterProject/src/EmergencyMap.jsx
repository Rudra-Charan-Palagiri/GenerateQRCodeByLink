import React, { useState } from 'react';
import './EmergencyMap.css';

// Simulated data for disaster locations
const disasterLocations = [
  { id: 1, lat: 34.0522, lng: -118.2437, type: 'Flood', severity: 'High', affected: 500 },
  { id: 2, lat: 40.7128, lng: -74.006, type: 'Fire', severity: 'Medium', affected: 120 },
  { id: 3, lat: 37.7749, lng: -122.4194, type: 'Earthquake', severity: 'Critical', affected: 1200 },
  { id: 4, lat: 29.7604, lng: -95.3698, type: 'Hurricane', severity: 'High', affected: 850 },
  { id: 5, lat: 41.8781, lng: -87.6298, type: 'Tornado', severity: 'Medium', affected: 320 }
];

const EmergencyMap = () => {
  const [selectedDisaster, setSelectedDisaster] = useState(null);

  const handleDisasterClick = (disaster) => {
    setSelectedDisaster(disaster);
  };

  return (
    <div className="map-wrapper">
      <div className="map-header">
        <h3 className="map-title">Disaster Incident Map</h3>
        <div className="map-legend">
          <div className="legend-item">
            <span className="legend-marker low"></span>
            <span>Low</span>
          </div>
          <div className="legend-item">
            <span className="legend-marker medium"></span>
            <span>Medium</span>
          </div>
          <div className="legend-item">
            <span className="legend-marker high"></span>
            <span>High</span>
          </div>
          <div className="legend-item">
            <span className="legend-marker critical"></span>
            <span>Critical</span>
          </div>
        </div>
      </div>
      
      {/* Placeholder for the map - in a real app, you would integrate with Google Maps, Mapbox, etc. */}
      <div className="map-container">
        <div className="map-overlay">
          <img 
            src="MapProject.jpg" 
            alt="Map Placeholder" 
            className="map-placeholder"
          />
          
          {/* Disaster markers */}
          {disasterLocations.map(disaster => (
            <button
              key={disaster.id}
              className={`map-marker ${disaster.severity.toLowerCase()}`}
              style={{ 
                left: `${(disaster.lng + 180) * (100 / 360)}%`, 
                top: `${(90 - disaster.lat) * (100 / 180)}%`
              }}
              onClick={() => handleDisasterClick(disaster)}
            ></button>
          ))}
        </div>
        
        {/* Disaster details panel */}
        {selectedDisaster && (
          <div className="disaster-panel">
            <div className="panel-header">
              <h4 className="panel-title">{selectedDisaster.type} Incident</h4>
              <button 
                className="panel-close"
                onClick={() => setSelectedDisaster(null)}
              >
                ×
              </button>
            </div>
            <div className="panel-content">
              <p className="panel-item"><span className="panel-label">Severity:</span> {selectedDisaster.severity}</p>
              <p className="panel-item"><span className="panel-label">Affected people:</span> {selectedDisaster.affected}</p>
              <p className="panel-item"><span className="panel-label">Coordinates:</span> {selectedDisaster.lat.toFixed(4)}, {selectedDisaster.lng.toFixed(4)}</p>
            </div>
            <div className="panel-footer">
              <button className="panel-button">View Detailed Report</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default EmergencyMap;