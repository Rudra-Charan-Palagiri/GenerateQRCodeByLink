import React, { useState } from 'react';
import Header from './Header';
import Footer from './Footer';
import './Alerts.css';

const Alerts = () => {
  const [subscribed, setSubscribed] = useState(false);
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [selectedRegions, setSelectedRegions] = useState([]);
  const [selectedAlertTypes, setSelectedAlertTypes] = useState([]);

  // Sample data for active alerts
  const alerts = [
    {
      id: 1,
      type: 'Hurricane Warning',
      severity: 'Critical',
      region: 'Coastal Region, FL',
      date: '2023-05-10T14:30:00',
      description: 'Category 3 hurricane approaching. Expected landfall in 24 hours. Mandatory evacuation for coastal zones A, B, and C. Shelters open at local high schools.',
      instructions: 'Evacuate immediately if in affected zones. Secure property. Bring emergency supplies for at least 72 hours.'
    },
    {
      id: 2,
      type: 'Flood Alert',
      severity: 'High',
      region: 'Riverside County, CA',
      date: '2023-05-10T10:15:00',
      description: 'Heavy rainfall causing flash flooding in low-lying areas. River expected to crest at 15 feet by evening, exceeding flood stage.',
      instructions: 'Avoid flooded roads. Move to higher ground if in flood-prone areas. Monitor local news for updates.'
    },
    {
      id: 3,
      type: 'Wildfire Warning',
      severity: 'High',
      region: 'Northern Hills, CA',
      date: '2023-05-10T08:45:00',
      description: 'Wildfire spreading rapidly due to high winds. Currently 2,500 acres and 10% contained. Smoke affecting air quality in surrounding areas.',
      instructions: 'Be prepared to evacuate if notified. Keep windows closed. Check air quality reports.'
    },
    {
      id: 4,
      type: 'Earthquake Advisory',
      severity: 'Medium',
      region: 'San Francisco Bay Area, CA',
      date: '2023-05-09T22:30:00',
      description: '5.2 magnitude earthquake occurred offshore. Aftershocks expected in the next 48 hours. No tsunami threat detected.',
      instructions: 'Check property for damage. Be prepared for aftershocks. Review earthquake safety procedures.'
    },
    {
      id: 5,
      type: 'Heat Advisory',
      severity: 'Medium',
      region: 'Phoenix Metropolitan Area, AZ',
      date: '2023-05-09T16:20:00',
      description: 'Excessive heat warning in effect. Temperatures expected to reach 110°F for the next 3 days.',
      instructions: 'Stay hydrated. Limit outdoor activities. Check on vulnerable neighbors. Never leave children or pets in vehicles.'
    }
  ];

  const regions = [
    'Northeast', 'Southeast', 'Midwest', 'Southwest', 'West Coast', 
    'Pacific Northwest', 'Rocky Mountains', 'Gulf Coast', 'Great Lakes', 'Alaska', 'Hawaii'
  ];

  const alertTypes = [
    'Hurricane', 'Tornado', 'Flood', 'Wildfire', 'Earthquake', 
    'Tsunami', 'Blizzard', 'Heat Wave', 'Air Quality', 'Volcanic Activity'
  ];

  const handleRegionChange = (e) => {
    const region = e.target.value;
    if (e.target.checked) {
      setSelectedRegions([...selectedRegions, region]);
    } else {
      setSelectedRegions(selectedRegions.filter(r => r !== region));
    }
  };

  const handleAlertTypeChange = (e) => {
    const alertType = e.target.value;
    if (e.target.checked) {
      setSelectedAlertTypes([...selectedAlertTypes, alertType]);
    } else {
      setSelectedAlertTypes(selectedAlertTypes.filter(t => t !== alertType));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!email && !phone) {
      alert("Please provide either an email or phone number.");
      return;
    }
    
    if (selectedRegions.length === 0) {
      alert("Please select at least one region.");
      return;
    }
    
    if (selectedAlertTypes.length === 0) {
      alert("Please select at least one alert type.");
      return;
    }
    
    // In a real app, you would send this data to your backend
    console.log('Alert preferences:', { email, phone, selectedRegions, selectedAlertTypes });
    
    // Success message
    setSubscribed(true);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  return (
    <div className="alerts-page">
      <Header />
      
      <main className="alerts-content">
        <h1 className="page-title">
          <span className="bell-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
              <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
            </svg>
          </span>
          Emergency Alerts
        </h1>
        
        <div className="alerts-grid">
          {/* Left column - Alert list */}
          <div className="alerts-list-container">
            <div className="alerts-section">
              <h2 className="section-title">Active Alerts</h2>
              
              <div className="alerts-list">
                {alerts.map(alert => (
                  <div key={alert.id} className={`alert-card ${alert.severity.toLowerCase()}`}>
                    <div className="alert-header">
                      <h3 className="alert-title">{alert.type}</h3>
                      <span className={`severity-badge ${alert.severity.toLowerCase()}`}>
                        {alert.severity}
                      </span>
                    </div>
                    
                    <div className="alert-meta">
                      <div>Location: <span className="meta-value">{alert.region}</span></div>
                      <div>Issued: <span className="meta-value">{formatDate(alert.date)}</span></div>
                    </div>
                    
                    <p className="alert-description">{alert.description}</p>
                    
                    <div className="instructions-box">
                      <div className="instructions-label">Instructions:</div>
                      <p className="instructions-text">{alert.instructions}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          {/* Right column - Alert subscription */}
          <div className="subscription-container">
            <div className="subscription-section">
              <h2 className="section-title">Alert Notifications</h2>
              
              {!subscribed ? (
                <form onSubmit={handleSubmit} className="subscription-form">
                  <p className="form-intro">
                    Subscribe to receive emergency alerts via email or SMS. Customize your preferences below.
                  </p>
                  
                  <div className="form-group">
                    <label htmlFor="email" className="form-label">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="form-input"
                      placeholder="your@email.com"
                    />
                  </div>
                  
                  <div className="form-group">
                    <label htmlFor="phone" className="form-label">
                      Phone (for SMS)
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="form-input"
                      placeholder="(555) 555-5555"
                    />
                  </div>
                  
                  <div className="form-group">
                    <label className="form-label">
                      Regions (select at least one)
                    </label>
                    <div className="checkbox-grid">
                      {regions.map(region => (
                        <label key={region} className="checkbox-label">
                          <input
                            type="checkbox"
                            value={region}
                            checked={selectedRegions.includes(region)}
                            onChange={handleRegionChange}
                            className="checkbox-input"
                          />
                          <span>{region}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                  
                  <div className="form-group">
                    <label className="form-label">
                      Alert Types (select at least one)
                    </label>
                    <div className="checkbox-grid">
                      {alertTypes.map(type => (
                        <label key={type} className="checkbox-label">
                          <input
                            type="checkbox"
                            value={type}
                            checked={selectedAlertTypes.includes(type)}
                            onChange={handleAlertTypeChange}
                            className="checkbox-input"
                          />
                          <span>{type}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                  
                  <div className="form-footer">
                    <button type="submit" className="subscribe-button">
                      Subscribe to Alerts
                    </button>
                  </div>
                </form>
              ) : (
                <div className="success-message">
                  <div className="success-icon">✓</div>
                  <h3>Successfully Subscribed!</h3>
                  <p>
                    You will now receive alerts for your selected regions and alert types.
                  </p>
                  <button
                    onClick={() => setSubscribed(false)}
                    className="modify-button"
                  >
                    Modify Preferences
                  </button>
                </div>
              )}
            </div>
            
            <div className="contacts-section">
              <h3 className="contacts-title">Emergency Contacts</h3>
              <ul className="contacts-list">
                <li className="contact-item">
                  <span className="contact-label">Emergency Hotline:</span>
                  <span className="contact-value">911</span>
                </li>
                <li className="contact-item">
                  <span className="contact-label">Disaster Relief:</span>
                  <span className="contact-value">1077</span>
                </li>
                <li className="contact-item">
                  <span className="contact-label">Medical Help:</span>
                  <span className="contact-value">108</span>
                </li>
                <li className="contact-item">
                  <span className="contact-label">Evacuation Info:</span>
                  <span className="contact-value">1099</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Alerts;
