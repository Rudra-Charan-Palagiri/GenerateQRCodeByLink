import React, { useState } from 'react';
import Header from './Header';
import Footer from './Footer';
import IncidentForm from './IncidentForm';
import './Incidents.css';

const Incidents = () => {
  // Sample data for incidents
  const [incidents, setIncidents] = useState([
    {
      id: 1,
      type: 'Flood',
      location: 'Riverside County, CA',
      date: '2023-05-10',
      severity: 'High',
      status: 'Active',
      description: 'Flash flooding affecting residential areas. Multiple streets closed.',
      peopleAffected: 320,
      responders: 45
    },
    {
      id: 2,
      type: 'Fire',
      location: 'Mountain View, CA',
      date: '2023-05-08',
      severity: 'Critical',
      status: 'Active',
      description: 'Wildfire spreading in forested areas. Evacuation orders in place for nearby communities.',
      peopleAffected: 1200,
      responders: 150
    },
    {
      id: 3,
      type: 'Earthquake',
      location: 'San Francisco, CA',
      date: '2023-05-05',
      severity: 'Medium',
      status: 'Recovery',
      description: '5.2 magnitude earthquake. Minor structural damage reported in older buildings.',
      peopleAffected: 800,
      responders: 95
    },
    {
      id: 4,
      type: 'Hurricane',
      location: 'Coastal Region, FL',
      date: '2023-04-28',
      severity: 'High',
      status: 'Recovery',
      description: 'Category 2 hurricane with significant flooding and wind damage.',
      peopleAffected: 2500,
      responders: 300
    },
    {
      id: 5,
      type: 'Tornado',
      location: 'Oklahoma City, OK',
      date: '2023-04-22',
      severity: 'High',
      status: 'Resolved',
      description: 'EF3 tornado passed through suburban areas causing significant damage.',
      peopleAffected: 450,
      responders: 120
    }
  ]);

  const [filter, setFilter] = useState({
    status: 'all',
    severity: 'all',
    type: 'all'
  });

  const [showForm, setShowForm] = useState(false);

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilter(prev => ({ ...prev, [name]: value }));
  };

  const filteredIncidents = incidents.filter(incident => {
    return (filter.status === 'all' || incident.status === filter.status) &&
           (filter.severity === 'all' || incident.severity === filter.severity) &&
           (filter.type === 'all' || incident.type === filter.type);
  });

  return (
    <div className="incidents-page">
      <Header />
      
      <main className="incidents-content">
        <div className="incidents-header">
          <h1 className="page-title">Incident Management</h1>
          <button 
            onClick={() => setShowForm(!showForm)}
            className="toggle-form-button"
          >
            {showForm ? 'Hide Form' : 'Report New Incident'}
          </button>
        </div>
        
        {showForm && (
          <div className="form-section">
            <IncidentForm />
          </div>
        )}
        
        <div className="filter-container">
          <h2 className="section-title">Filter Incidents</h2>
          <div className="filter-controls">
            <div className="filter-group">
              <label htmlFor="status" className="filter-label">
                Status
              </label>
              <select
                id="status"
                name="status"
                value={filter.status}
                onChange={handleFilterChange}
                className="filter-select"
              >
                <option value="all">All Statuses</option>
                <option value="Active">Active</option>
                <option value="Recovery">Recovery</option>
                <option value="Resolved">Resolved</option>
              </select>
            </div>
            
            <div className="filter-group">
              <label htmlFor="severity" className="filter-label">
                Severity
              </label>
              <select
                id="severity"
                name="severity"
                value={filter.severity}
                onChange={handleFilterChange}
                className="filter-select"
              >
                <option value="all">All Severities</option>
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
                <option value="Critical">Critical</option>
              </select>
            </div>
            
            <div className="filter-group">
              <label htmlFor="type" className="filter-label">
                Incident Type
              </label>
              <select
                id="type"
                name="type"
                value={filter.type}
                onChange={handleFilterChange}
                className="filter-select"
              >
                <option value="all">All Types</option>
                <option value="Flood">Flood</option>
                <option value="Fire">Fire</option>
                <option value="Earthquake">Earthquake</option>
                <option value="Hurricane">Hurricane</option>
                <option value="Tornado">Tornado</option>
                <option value="Landslide">Landslide</option>
              </select>
            </div>
          </div>
        </div>
        
        <div className="incidents-table-container">
          <table className="incidents-table">
            <thead>
              <tr>
                <th>Type</th>
                <th>Location</th>
                <th>Date</th>
                <th>Severity</th>
                <th>Status</th>
                <th>People Affected</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredIncidents.map(incident => (
                <tr key={incident.id}>
                  <td className="incident-type">{incident.type}</td>
                  <td>{incident.location}</td>
                  <td>{incident.date}</td>
                  <td>
                    <span className={`severity-badge ${incident.severity.toLowerCase()}`}>
                      {incident.severity}
                    </span>
                  </td>
                  <td>
                    <span className={`status-badge ${incident.status.toLowerCase()}`}>
                      {incident.status}
                    </span>
                  </td>
                  <td>{incident.peopleAffected}</td>
                  <td className="actions-cell">
                    <button className="action-button view">View Details</button>
                    <button className="action-button update">Update</button>
                  </td>
                </tr>
              ))}
              
              {filteredIncidents.length === 0 && (
                <tr className="empty-row">
                  <td colSpan="7">
                    No incidents match your filter criteria
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Incidents;