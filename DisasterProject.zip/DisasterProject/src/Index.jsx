import React, { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from './Header';
import Footer from './Footer';
import EmergencyMap from './EmergencyMap';
import EmergencyStats from './EmergencyStats';
import RecentAlerts from './RecentAlerts';
import IncidentForm from './IncidentForm';
import './Index.css';

const Index = () => {
  const incidentFormRef = useRef(null);
  const [showContacts, setShowContacts] = useState(false);
  const navigate = useNavigate();

  const scrollToIncidentForm = () => {
    incidentFormRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleVolunteerClick = () => {
    navigate('/volunteers');
  };

  return (
    <div className="app-container">
      <Header />

      <main className="main-content">
        <div className="dashboard-grid">
          {/* Left column */}
          <div className="dashboard-column left-column">
            <h2 className="section-heading">Emergency Overview</h2>
            <EmergencyStats />

            <div className="section-container">
              <h3 className="subsection-heading">Quick Actions</h3>
              <div className="quick-actions">
                <button className="quick-action emergency" onClick={scrollToIncidentForm}>
                  <span className="action-icon">🆘</span>
                  <span className="action-label">Report Emergency</span>
                </button>
                <button className="quick-action contacts" onClick={() => setShowContacts(true)}>
                  <span className="action-icon">📱</span>
                  <span className="action-label">Emergency Contacts</span>
                </button>
                <button className="quick-action volunteer" onClick={handleVolunteerClick}>
                  <span className="action-icon">🙋</span>
                  <span className="action-label">Volunteer</span>
                </button>
                <button className="quick-action donate">
                  <span className="action-icon">💰</span>
                  <span className="action-label">Donate</span>
                </button>
              </div>
            </div>

            <div className="section-container">
              <RecentAlerts />
            </div>
          </div>

          {/* Right column */}
          <div className="dashboard-column right-column">
            <EmergencyMap />
            <div ref={incidentFormRef}>
              <IncidentForm />
            </div>
          </div>
        </div>
      </main>

      <Footer />

      {/* Modal for Emergency Contacts */}
      {showContacts && (
        <div className="modal-overlay" onClick={() => setShowContacts(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <button className="modal-close" onClick={() => setShowContacts(false)}>&times;</button>
            <h3>Emergency Contacts</h3>
            <ul className="contacts-list">
              <li><strong>Police:</strong> 100</li>
              <li><strong>Fire:</strong> 101</li>
              <li><strong>Ambulance:</strong> 108</li>
              <li><strong>Women Helpline:</strong> 181</li>
              <li><strong>Disaster Helpline:</strong> 1077</li>
              <li><strong>Child Helpline:</strong> 1098</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};

export default Index;
