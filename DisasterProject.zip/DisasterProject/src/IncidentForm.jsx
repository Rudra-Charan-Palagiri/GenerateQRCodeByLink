import React, { useState } from 'react';
import './IncidentForm.css';

const IncidentForm = () => {
  const [formData, setFormData] = useState({
    incidentType: '',
    location: '',
    severity: 'Medium',
    description: '',
    peopleAffected: '',
    contactName: '',
    contactPhone: '',
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validate form
    if (!formData.incidentType || !formData.location || !formData.description) {
      alert("Please fill in all required fields.");
      return;
    }
    
    // In a real app, you would send this data to your backend
    console.log('Incident reported:', formData);
    
    // Show success message
    setSubmitted(true);
    
    // Reset form after a delay
    setTimeout(() => {
      setFormData({
        incidentType: '',
        location: '',
        severity: 'Medium',
        description: '',
        peopleAffected: '',
        contactName: '',
        contactPhone: '',
      });
      setSubmitted(false);
    }, 3000);
  };

  return (
    <div className="form-container">
      <h2 className="form-heading">Report New Incident</h2>
      
      {submitted ? (
        <div className="success-message">
          <div className="success-icon">✓</div>
          <h3>Incident Reported</h3>
          <p>Your incident has been successfully reported. Emergency teams have been notified.</p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="incident-form">
          <div className="form-row">
            <div className="form-group">
              <label htmlFor="incidentType" className="form-label">
                Incident Type*
              </label>
              <select
                id="incidentType"
                name="incidentType"
                value={formData.incidentType}
                onChange={handleChange}
                className="form-select"
                required
              >
                <option value="">Select incident type</option>
                <option value="Flood">Flood</option>
                <option value="Fire">Fire</option>
                <option value="Earthquake">Earthquake</option>
                <option value="Hurricane">Hurricane</option>
                <option value="Tornado">Tornado</option>
                <option value="Landslide">Landslide</option>
                <option value="Other">Other</option>
              </select>
            </div>
            
            <div className="form-group">
              <label htmlFor="location" className="form-label">
                Location*
              </label>
              <input
                type="text"
                id="location"
                name="location"
                value={formData.location}
                onChange={handleChange}
                placeholder="City, State or Specific Address"
                className="form-input"
                required
              />
            </div>
          </div>
          
          <div className="form-group">
            <label className="form-label">
              Severity
            </label>
            <div className="radio-group">
              {['Low', 'Medium', 'High', 'Critical'].map((level) => (
                <label key={level} className="radio-label">
                  <input
                    type="radio"
                    name="severity"
                    value={level}
                    checked={formData.severity === level}
                    onChange={handleChange}
                    className="radio-input"
                  />
                  <span>{level}</span>
                </label>
              ))}
            </div>
          </div>
          
          <div className="form-group">
            <label htmlFor="description" className="form-label">
              Description*
            </label>
            <textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              rows="3"
              placeholder="Please provide details about the incident..."
              className="form-textarea"
              required
            ></textarea>
          </div>
          
          <div className="form-group">
            <label htmlFor="peopleAffected" className="form-label">
              Estimated People Affected
            </label>
            <input
              type="number"
              id="peopleAffected"
              name="peopleAffected"
              value={formData.peopleAffected}
              onChange={handleChange}
              min="0"
              placeholder="Number of people affected"
              className="form-input"
            />
          </div>
          
          <div className="form-row">
            <div className="form-group">
              <label htmlFor="contactName" className="form-label">
                Contact Name
              </label>
              <input
                type="text"
                id="contactName"
                name="contactName"
                value={formData.contactName}
                onChange={handleChange}
                placeholder="Your name"
                className="form-input"
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="contactPhone" className="form-label">
                Contact Phone
              </label>
              <input
                type="tel"
                id="contactPhone"
                name="contactPhone"
                value={formData.contactPhone}
                onChange={handleChange}
                placeholder="Your phone number"
                className="form-input"
              />
            </div>
          </div>
          
          <div className="form-footer">
            <button
              type="submit"
              className="submit-button"
            >
              Report Incident
            </button>
          </div>
        </form>
      )}
    </div>
  );
};

export default IncidentForm;
