import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Header.css';

const Header = () => {
  const navigate = useNavigate();
  const [loggedInUser, setLoggedInUser] = useState(null);

  useEffect(() => {
    const user = localStorage.getItem('loggedInUser');
    if (user) setLoggedInUser(user);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('loggedInUser');
    setLoggedInUser(null);
    navigate('/login');
  };

  const navigateTo = (path) => {
    navigate(path);
  };

  return (
    <header className="header">
      <div className="header-container">
        <div className="logo" onClick={() => navigateTo('/')}>
          <div className="shield-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
            </svg>
          </div>
          <h1>DisasterResponse</h1>
        </div>

        <nav className="navigation">
          <button onClick={() => navigateTo('/')} className="nav-item">🏠 Dashboard</button>
          <button onClick={() => navigateTo('/incidents')} className="nav-item">📄 Incidents</button>
          <button onClick={() => navigateTo('/volunteers')} className="nav-item">🤝 Volunteers</button>
          <button onClick={() => navigateTo('/alerts')} className="nav-item">🚨 Alerts</button>
        </nav>

        <div className="auth-buttons">
          {loggedInUser ? (
            <div className="profile-section">
              <img 
                src="https://cdn-icons-png.flaticon.com/512/149/149071.png" 
                alt="User Icon" 
                className="profile-icon"
                style={{ width: '32px', height: '32px', borderRadius: '50%', marginRight: '8px' }}
              />
              <span style={{ marginRight: '12px' }}>{loggedInUser}</span>
              <button onClick={handleLogout} className="auth-button logout-btn">Log Out</button>
            </div>
          ) : (
            <>
              <button onClick={() => navigateTo('/login')} className="auth-button login-btn">Log In</button>
              <button onClick={() => navigateTo('/signup')} className="auth-button signup-btn">Sign Up</button>
            </>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
