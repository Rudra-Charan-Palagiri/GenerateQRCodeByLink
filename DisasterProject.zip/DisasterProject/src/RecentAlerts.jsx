import React from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate
import './RecentAlerts.css';

const RecentAlerts = () => {
  const navigate = useNavigate(); // Initialize useNavigate

  // Sample data for recent alerts
  const alerts = [
    {
      id: 1, 
      type: 'Hurricane Warning', 
      location: 'Coastal Region, FL', 
      timestamp: '15 min ago',
      severity: 'Critical',
      message: 'Category 3 hurricane approaching. Immediate evacuation required for zones A and B.'
    },
    {
      id: 2, 
      type: 'Flood Alert', 
      location: 'Riverside County', 
      timestamp: '1 hour ago',
      severity: 'High',
      message: 'River levels rising rapidly. Residents in low-lying areas should prepare for possible evacuation.'
    },
    {
      id: 3, 
      type: 'Wildfire Update', 
      location: 'Northern Hills', 
      timestamp: '3 hours ago',
      severity: 'Medium',
      message: 'Wildfire 40% contained. Air quality remains poor in affected areas.'
    },
    {
      id: 4, 
      type: 'Road Closure', 
      location: 'Highway 101', 
      timestamp: '5 hours ago',
      severity: 'Low',
      message: 'Highway closed due to landslide. Use alternative routes until further notice.'
    }
  ];

  return (
    <div className="alerts-container">
      <div className="alerts-header">
        <div className="alerts-title">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="bell-icon">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
            <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
          </svg>
          <h2>Recent Alerts</h2>
        </div>
        <button className="view-all" onClick={() => navigate('/alerts')}>View All</button> {/* Add onClick to navigate */}
      </div>

      <div className="alerts-list">
        {alerts.map(alert => (
          <div key={alert.id} className={`alert-item ${alert.severity.toLowerCase()}`}>
            <div className="alert-header">
              <h3 className="alert-type">{alert.type}</h3>
              <span className={`alert-severity ${alert.severity.toLowerCase()}`}>
                {alert.severity}
              </span>
            </div>
            <p className="alert-message">{alert.message}</p>
            <div className="alert-meta">
              <span className="alert-location">{alert.location}</span>
              <span className="alert-time">{alert.timestamp}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RecentAlerts;
