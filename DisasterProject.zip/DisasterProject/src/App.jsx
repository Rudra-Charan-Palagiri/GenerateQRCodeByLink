import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./Index";
import Incidents from "./Incidents";
import Volunteers from "./Volunteers";
import Alerts from "./Alerts";
import Login from "./Login";
import Signup from "./Signup";
import NotFound from "./NotFound";
import Profile from "./Profile"; // ✅ Import Profile component
import "./App.css";

const App = () => (
  <>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/incidents" element={<Incidents />} />
        <Route path="/volunteers" element={<Volunteers />} />
        <Route path="/alerts" element={<Alerts />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/profile" element={<Profile />} /> {/* ✅ Add Profile route */}
        {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  </>
);

export default App;
