package disasterBackend.controller;

import disasterBackend.model.DisasterReport;
import disasterBackend.repository.DisasterReportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins = "*")
public class DisasterReportController {

    @Autowired
    private DisasterReportRepository repository;

    @PostMapping
    public DisasterReport submitReport(@RequestBody DisasterReport report) {
        return repository.save(report);
    }

    @GetMapping
    public List<DisasterReport> getAllReports() {
        return repository.findAll();
    }
}
